# AfroFlix Bénin — Étape 20 : Mise en production 🌍🔥

Étape finale du parcours 1→20 : préparation structurée au déploiement réel.

## Inclus
- Endpoint de santé `/api/health`.
- Dockerfile de production Node.js 20.
- Docker Compose avec AfroFlix + Nginx.
- Configuration Nginx de reverse proxy.
- Exemple de variables d'environnement de production.
- Script de sauvegarde SQLite + uploads.
- Guide de déploiement et checklist de lancement.
- Conservation des fonctions des étapes précédentes : admin, sécurité, notifications et préparation Android.

## Démarrage local
```bash
npm install
npm start
```

## Production
```bash
cp .env.production.example .env.production
# modifier .env.production
# modifier deploy/nginx.conf avec votre domaine
docker compose up -d --build
```

## Important
Le ZIP ne contient pas de domaine, certificat, compte serveur ou identifiants de paiement réels. Ces ressources dépendent de tes fournisseurs et doivent être configurées avec tes propres secrets.

## Étape 21 — Chaînes TV
Cette version ajoute une architecture de chaînes : AfroFlix TV, Music, Films, Sport, Culture et Kids, une page `/channels.html`, une page `/channel.html?slug=...`, des API de chaînes, le suivi des chaînes et la gestion administrateur des chaînes/programmes. Le champ `stream_url` est prévu pour recevoir plus tard une URL HLS réelle. Cette étape ne fournit pas encore le serveur de diffusion live : il sera branché à l'étape Direct TV.

## 🔴 Étape 22 — Vrai direct TV local

Le projet intègre maintenant **MediaMTX** pour recevoir un flux RTMP depuis OBS et le servir en HLS.

### Démarrage

```powershell
docker compose up -d
```

Dans OBS : **Paramètres → Flux → Service personnalisé**
- Serveur : `rtmp://localhost:1935`
- Clé : `afroflix-tv`

Puis clique sur **Commencer le streaming**.

La Chaîne 1 lit ensuite : `http://localhost:8888/afroflix-tv/index.m3u8`

Guide complet : `streaming/README.md`.


## Étape 23 — Accueil AfroFlix unifié
Cette version conserve les fonctions précédentes et réunit l'expérience dans un accueil unique : catalogue, chaînes TV, direct, replay préparé, recherche, compte, Premium et créateurs. Les pages Films, Premium, Profil et Auth sont désormais présentes et la Ma liste possède ses API.


## Étape 24 — Direct TV + application

La page `/live.html` centralise le direct de toutes les chaînes. La préparation Capacitor Android est conservée dans `mobile-android/`. Le direct local reste : OBS → MediaMTX → HLS → AfroFlix.
