# AfroFlix Bénin — Android & Android TV (Étape 24)

Cette étape prépare l'application mobile à partir du même site AfroFlix. Le projet conserve le même backend et les mêmes pages web.

## Préparer Android

Prérequis sur le PC : Node.js LTS, Android Studio et Android SDK.

Depuis ce dossier :

```powershell
npm install
npm run add:android
npm run sync
npm run open:android
```

Dans Android Studio, on pourra ensuite lancer l'application sur un téléphone ou un émulateur.

## Android TV / Google TV

Le même projet web est pensé pour une interface télécommande : grandes cartes, navigation simple et lecteur plein écran. La génération d'un APK/Android TV final nécessite Android Studio et les outils SDK sur le PC.

## Direct TV

La page `/live.html` regroupe les chaînes et utilise HLS. En test local, les flux utilisent MediaMTX : `http://localhost:8888/<slug>/index.m3u8`. En production, ces URLs devront pointer vers le serveur public AfroFlix en HTTPS.

## Important

Cette étape prépare et intègre l'application ; elle ne prétend pas avoir compilé un APK ici. La compilation finale se fait sur ton PC avec Android Studio.
