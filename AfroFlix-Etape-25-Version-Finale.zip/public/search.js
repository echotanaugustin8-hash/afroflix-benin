const state={movies:[]};
const $=id=>document.getElementById(id);
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function score(m,q){
  if(!q)return 0;
  const t=(m.title+' '+(m.genre||'')+' '+(m.language||'')+' '+(m.description||'')).toLowerCase();
  let s=0;
  if((m.title||'').toLowerCase().includes(q))s+=100;
  if(t.includes(q))s+=30;
  return s+(Number(m.rating)||0)*2+(Number(m.views)||0)/100000;
}
function render(){
  const q=$('q').value.trim().toLowerCase(), genre=$('genre').value, language=$('language').value;
  const year=$('year').value, access=$('access').value, sort=$('sort').value;
  let list=state.movies.filter(m=>{
    const text=(m.title+' '+(m.genre||'')+' '+(m.language||'')+' '+(m.description||'')).toLowerCase();
    return (!q||text.includes(q))&&(!genre||m.genre===genre)&&(!language||m.language===language)&&(!year||String(m.year)===year)&&(!access||(access==='premium'?!!m.premium:!m.premium));
  });
  if(sort==='rating')list.sort((a,b)=>(b.rating||0)-(a.rating||0));
  else if(sort==='newest')list.sort((a,b)=>(b.year||0)-(a.year||0));
  else if(sort==='views')list.sort((a,b)=>(b.views||0)-(a.views||0));
  else list.sort((a,b)=>score(b,q)-score(a,q));
  $('count').textContent=`${list.length} contenu${list.length>1?'s':''}`;
  $('active').textContent=q?`Recherche : “${q}”`:'';
  $('grid').innerHTML=list.map(m=>`<article class="movie-card">
    <div class="poster"><strong>${esc(m.title)}</strong></div>
    <div class="movie-info"><b>${esc(m.title)}</b>
      <div class="meta">${esc(m.genre||'Film')} · ${m.year||'—'} · ${m.premium?'Premium':'Gratuit'}</div>
      <p>${esc((m.description||'').slice(0,90))}</p>
      <div class="movie-actions"><a class="primary" href="/player.html?id=${m.id}">▶ Voir</a><button onclick="add(${m.id})">＋ Liste</button></div>
    </div></article>`).join('');
  $('empty').hidden=list.length!==0;
}
async function load(){
  try{
    const r=await fetch('/api/movies'); state.movies=await r.json();
    const genres=[...new Set(state.movies.map(m=>m.genre).filter(Boolean))].sort();
    genres.forEach(g=>$('genre').insertAdjacentHTML('beforeend',`<option>${esc(g)}</option>`));
    const years=[...new Set(state.movies.map(m=>m.year).filter(Boolean))].sort((a,b)=>b-a);
    years.forEach(y=>$('year').insertAdjacentHTML('beforeend',`<option>${y}</option>`));
    render();
  }catch(e){$('count').textContent='Catalogue indisponible';}
}
['q','genre','language','year','access','sort'].forEach(id=>$(id).addEventListener(id==='q'?'input':'change',render));
$('clear').onclick=()=>{$('q').value='';render();$('q').focus()};
async function add(id){
  const token=localStorage.getItem('afroflix_token');
  if(!token){location.href='/auth.html';return}
  await fetch('/api/watchlist',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify({movie_id:id})});
  alert('Ajouté à Ma liste');
}
load();
