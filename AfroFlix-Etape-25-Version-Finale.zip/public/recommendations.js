const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
function card(m){
 return `<article class="movie-card"><div class="poster"><strong>${esc(m.title)}</strong></div>
 <div class="movie-info"><b>${esc(m.title)}</b><div class="meta">${esc(m.genre||'Film')} · ${m.year||'—'} · ${m.premium?'Premium':'Gratuit'} · ⭐ ${m.rating||'—'}</div>
 <div class="reason">${esc(m.recommendation_reason||'Sélection AfroFlix')}</div><a href="/player.html?id=${m.id}">▶ Regarder</a></div></article>`;
}
async function load(){
 const token=localStorage.getItem('afroflix_token');
 try{
  if(!token){$('status').textContent='Connectez-vous pour personnaliser';}
  const h=token?{Authorization:'Bearer '+token}:{};
  const r=await fetch('/api/recommendations?limit=8',{headers:h});
  if(r.ok){const data=await r.json();$('grid').innerHTML=data.map(card).join('');}
  const all=await fetch('/api/movies'); const movies=await all.json();
  movies.sort((a,b)=>(b.views||0)-(a.views||0)); $('trending').innerHTML=movies.slice(0,8).map(m=>card({...m,recommendation_reason:'Parmi les plus vus sur AfroFlix'})).join('');
 }catch(e){$('status').textContent='Impossible de charger les recommandations';}
}
load();
