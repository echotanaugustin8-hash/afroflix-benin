const token=localStorage.getItem("afroflix_token");
const $=id=>document.getElementById(id);
if(!token){ location.href="auth.html"; }

async function api(url,opt={}){
 opt.headers={...(opt.headers||{}),Authorization:"Bearer "+token,"Content-Type":"application/json"};
 const r=await fetch(url,opt); const data=await r.json().catch(()=>({}));
 if(!r.ok) throw new Error(data.error||"Erreur");
 return data;
}
async function load(){
 try{
  const me=await api("/api/creator/me");
  if(!me.creator){
    $("apply").classList.remove("hidden"); $("dashboard").classList.add("hidden"); return;
  }
  $("applyForm").classList.add("hidden");
  $("creatorState").innerHTML=`<p class="muted">Statut de votre candidature : <b>${me.creator.status}</b></p>`;
  if(me.creator.status!=="approved"){
    $("dashboard").classList.add("hidden");
    return;
  }
  $("apply").classList.add("hidden"); $("dashboard").classList.remove("hidden");
  $("creatorName").textContent=me.creator.display_name+" · "+me.creator.country;
  await Promise.all([stats(),movies()]);
 }catch(e){alert(e.message);}
}
async function stats(){
 const s=await api("/api/creator/stats");
 $("sTotal").textContent=s.total;$("sPublished").textContent=s.published;$("sPending").textContent=s.pending;$("sViews").textContent=s.views;
}
async function movies(){
 const data=await api("/api/creator/movies");
 $("movies").innerHTML=data.length?data.map(m=>`
 <div class="movie">
  <h3>${esc(m.title)}</h3>
  <span class="badge ${m.status}">${m.status}</span>
  <p class="muted">${esc(m.genre)} · ${m.year||"—"} · ${m.views} vues ${m.rejection_reason?`<br>Motif : ${esc(m.rejection_reason)}`:""}</p>
  <div class="actions">
   ${["draft","rejected"].includes(m.status)?`<button class="submit" onclick="submitMovie(${m.id})">Envoyer en modération</button>`:""}
   ${["draft","rejected"].includes(m.status)?`<button class="danger" onclick="deleteMovie(${m.id})">Supprimer</button>`:""}
  </div>
 </div>`).join(""):"<p class='muted'>Aucun contenu pour le moment.</p>";
}
function esc(v){return String(v??"").replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[s]));}
$("applyForm").addEventListener("submit",async e=>{
 e.preventDefault();
 try{
  await api("/api/creator/apply",{method:"POST",body:JSON.stringify({
   display_name:$("display_name").value,bio:$("bio").value,country:$("country").value,social_link:$("social_link").value
  })});
  $("creatorState").innerHTML="<p>✅ Candidature envoyée. Attendez la validation de l'administration.</p>";
  $("applyForm").classList.add("hidden");
 }catch(e){alert(e.message)}
});
async function upload(file){
 const fd=new FormData();fd.append("file",file);
 const r=await fetch("/api/uploads",{method:"POST",headers:{Authorization:"Bearer "+token},body:fd});
 const d=await r.json();if(!r.ok)throw new Error(d.error||"Upload impossible");return d.url;
}
$("movieForm").addEventListener("submit",async e=>{
 e.preventDefault();$("msg").textContent="Enregistrement...";
 try{
  let poster=$("poster_url").value, video=$("video_url").value;
  if($("posterFile").files[0]) poster=await upload($("posterFile").files[0]);
  if($("videoFile").files[0]) video=await upload($("videoFile").files[0]);
  await api("/api/creator/movies",{method:"POST",body:JSON.stringify({
   title:$("title").value,genre:$("genre").value,year:$("year").value,rating:$("rating").value,
   description:$("description").value,premium:$("premium").checked,poster_url:poster,video_url:video,duration:$("duration").value
  })});
  $("msg").textContent="✅ Brouillon enregistré.";
  e.target.reset(); await stats();await movies();
 }catch(e){$("msg").textContent="❌ "+e.message}
});
async function submitMovie(id){try{await api("/api/creator/movies/"+id+"/submit",{method:"POST"});await stats();await movies()}catch(e){alert(e.message)}}
async function deleteMovie(id){if(!confirm("Supprimer ce contenu ?"))return;try{await api("/api/creator/movies/"+id,{method:"DELETE"});await stats();await movies()}catch(e){alert(e.message)}}
$("refresh").onclick=load;
load();