const token=localStorage.getItem("afroflix_token");
const $=id=>document.getElementById(id);
async function api(url,opt={}){
 opt.headers={...(opt.headers||{}),Authorization:"Bearer "+token,"Content-Type":"application/json"};
 const r=await fetch(url,opt);const d=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(d.error||"Erreur");return d;
}
async function load(){
 try{
  const [cs,ms]=await Promise.all([api("/api/admin/creators"),api("/api/admin/creator-submissions")]);
  $("creators").innerHTML=cs.map(c=>`<div class="row"><b>${esc(c.display_name)}</b><span>${esc(c.email)}</span><span>${c.status}</span><span>${c.movie_count} films</span>
  ${c.status==="pending"?`<button onclick="approveCreator(${c.id})">Approuver</button><button class="red" onclick="rejectCreator(${c.id})">Refuser</button>`:""}</div>`).join("")||"<p>Aucune candidature.</p>";
  $("submissions").innerHTML=ms.map(m=>`<div class="row"><b>${esc(m.title)}</b><span>${esc(m.creator_name)}</span><span class="badge">${m.status}</span>
  <button onclick="approveMovie(${m.id})">Publier</button><button class="red" onclick="rejectMovie(${m.id})">Refuser</button></div>`).join("")||"<p>Aucun contenu en attente.</p>";
 }catch(e){alert(e.message)}
}
function esc(v){return String(v??"").replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[s]));}
async function approveCreator(id){await api("/api/admin/creators/"+id+"/approve",{method:"POST"});load()}
async function rejectCreator(id){await api("/api/admin/creators/"+id+"/reject",{method:"POST"});load()}
async function approveMovie(id){await api("/api/admin/movies/"+id+"/approve",{method:"POST"});load()}
async function rejectMovie(id){const reason=prompt("Motif du refus ?","Veuillez corriger le contenu.");if(reason===null)return;await api("/api/admin/movies/"+id+"/reject",{method:"POST",body:JSON.stringify({reason})});load()}
load();