const token=localStorage.getItem('afroflix_token');const h={Authorization:'Bearer '+token};
const money=n=>new Intl.NumberFormat('fr-FR').format(Math.round(n||0))+' FCFA';
async function load(){
 if(!token){location.href='/auth.html';return}
 const r=await fetch('/api/creator/earnings',{headers:h}); const d=await r.json();
 if(!r.ok){document.getElementById('notice').textContent=d.error||'Accès refusé';return}
 views.textContent=new Intl.NumberFormat('fr-FR').format(d.total_views);
 balance.textContent=money(d.creator_amount); share.textContent=d.revenue_share_percent+'%';
 movies.innerHTML=d.movies.map(m=>`<div class="movie-row"><b>${m.title}</b><span>${Number(m.views||0).toLocaleString('fr-FR')} vues</span></div>`).join('');
 loadWithdrawals();
}
async function loadWithdrawals(){const r=await fetch('/api/creator/withdrawals',{headers:h});if(!r.ok)return;const d=await r.json();withdrawals.innerHTML=d.map(x=>`<div class="movie-row"><b>${money(x.amount)}</b><span>${x.method} · ${x.status}</span></div>`).join('')}
form.onsubmit=async e=>{e.preventDefault();const r=await fetch('/api/creator/withdrawals',{method:'POST',headers:{...h,'Content-Type':'application/json'},body:JSON.stringify({amount:Number(amount.value),method:method.value,destination:destination.value})});const d=await r.json();alert(d.error||'Demande envoyée');if(r.ok){form.reset();load()}}
load();
