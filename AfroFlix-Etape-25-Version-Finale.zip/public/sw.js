const CACHE="afroflix-v10";
const APP_SHELL=["/","/index.html","/films.html","/auth.html","/profile.html","/premium.html","/creator.html","/player.html","/creator.css","/creator.js","/player.css","/player.js","/manifest.webmanifest"];
self.addEventListener("install",e=>{
 e.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP_SHELL).catch(()=>{})));
 self.skipWaiting();
});
self.addEventListener("activate",e=>{
 e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
 self.clients.claim();
});
self.addEventListener("fetch",e=>{
 const req=e.request;
 if(req.method!=="GET") return;
 const url=new URL(req.url);
 // API and streaming are network-first; do not cache private/premium responses.
 if(url.pathname.startsWith("/api/")) return;
 if(url.pathname.startsWith("/uploads/") || url.pathname.startsWith("/videos/")) return;
 e.respondWith(
   fetch(req).then(res=>{
     const copy=res.clone();
     caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{});
     return res;
   }).catch(()=>caches.match(req).then(r=>r||caches.match("/index.html")))
 );
});