const token=localStorage.getItem('afroflix_token');
const params=new URLSearchParams(location.search), id=params.get('id');
const video=document.getElementById('video'), title=document.getElementById('title'), meta=document.getElementById('meta');
const quality=document.getElementById('quality'), resume=document.getElementById('resume'), msg=document.getElementById('message');
let duration=0,lastSaved=0,info=null;
function auth(){return token?{Authorization:'Bearer '+token}:{}}
function say(t){msg.textContent=t;msg.style.display='block';setTimeout(()=>msg.style.display='none',3500)}
async function load(){
 if(!id){say('Film introuvable');return}
 if(!token){say('Connectez-vous pour regarder');return}
 try{
  const r=await fetch('/api/movies/'+id+'/stream-info',{headers:auth()});
  const d=await r.json(); if(!r.ok) throw new Error(d.error||'Accès refusé');
  info=d; title.textContent=d.title; meta.textContent='Lecture sécurisée · '+(d.duration||'');
  let qs=d.qualities||[];
  if(d.hls) qs=[{label:'Auto',url:d.hls},...qs];
  if(!qs.length){say('Aucune vidéo configurée pour ce film');return}
  quality.innerHTML=qs.map((q,i)=>`<option value="${encodeURIComponent(q.url)}">${q.label||('Qualité '+(i+1))}</option>`).join('');
  setSource(qs[0].url);
  loadHistory();
 }catch(e){say(e.message)}
}
function setSource(url){
 const current=video.currentTime||0; video.src=url; video.load();
 video.addEventListener('loadedmetadata',()=>{duration=video.duration||0;if(current)video.currentTime=current},{once:true});
}
quality.addEventListener('change',()=>{const pos=video.currentTime;setSource(decodeURIComponent(quality.value));video.addEventListener('loadedmetadata',()=>video.currentTime=pos,{once:true})});
video.addEventListener('loadedmetadata',()=>{duration=video.duration||0});
video.addEventListener('timeupdate',()=>{
 if(!token||!id||Math.abs(video.currentTime-lastSaved)<10)return;
 lastSaved=video.currentTime;
 fetch('/api/history/'+id,{method:'POST',headers:{...auth(),'Content-Type':'application/json'},body:JSON.stringify({progress_seconds:video.currentTime,duration_seconds:duration})});
});
video.addEventListener('play',()=>fetch('/api/playback-event',{method:'POST',headers:{...auth(),'Content-Type':'application/json'},body:JSON.stringify({movie_id:Number(id),event:'play',position_seconds:video.currentTime})}));
video.addEventListener('ended',()=>fetch('/api/playback-event',{method:'POST',headers:{...auth(),'Content-Type':'application/json'},body:JSON.stringify({movie_id:Number(id),event:'complete',position_seconds:video.duration||0})}));
async function loadHistory(){
 const r=await fetch('/api/history',{headers:auth()}); if(!r.ok)return;
 const rows=await r.json(); const h=rows.find(x=>Number(x.movie_id)===Number(id));
 if(h && h.progress_seconds>10 && h.progress_seconds<(h.duration_seconds-10||Infinity)){
   resume.textContent=`Reprise automatique à ${Math.floor(h.progress_seconds/60)}:${String(Math.floor(h.progress_seconds%60)).padStart(2,'0')}`;
   video.addEventListener('loadedmetadata',()=>{video.currentTime=h.progress_seconds},{once:true});
 } else resume.textContent='Votre progression est enregistrée automatiquement.';
}
load();
