(function(){
 let deferred=null;
 const key="afroflix-install-dismissed";
 window.addEventListener("beforeinstallprompt",e=>{
   e.preventDefault(); deferred=e;
   if(localStorage.getItem(key)) return;
   const box=document.createElement("div");
   box.id="installBox";
   box.innerHTML='<div><b>📱 Installer AfroFlix</b><small>Ajoutez AfroFlix à votre écran d’accueil.</small></div><button id="installBtn">Installer</button><button id="closeInstall">×</button>';
   box.style.cssText="position:fixed;left:12px;right:12px;bottom:14px;z-index:9999;background:#151515;color:#fff;border:1px solid #333;border-radius:14px;padding:12px;display:flex;align-items:center;gap:12px;justify-content:space-between;font-family:Arial;box-shadow:0 12px 35px #000";
   box.querySelector("small").style.cssText="display:block;color:#aaa;margin-top:3px";
   box.querySelector("#installBtn").style.cssText="background:#e50914;color:#fff;border:0;border-radius:8px;padding:9px 12px;font-weight:700";
   box.querySelector("#closeInstall").style.cssText="background:none;color:#aaa;border:0;font-size:22px";
   document.body.appendChild(box);
   box.querySelector("#installBtn").onclick=async()=>{
     deferred.prompt(); await deferred.userChoice; deferred=null; box.remove();
   };
   box.querySelector("#closeInstall").onclick=()=>{localStorage.setItem(key,"1");box.remove()};
 });
})();